/usr/local/redis/src/redis-cli -p 6379 shutdown
/usr/local/redis/src/redis-cli -p 6380 shutdown
/usr/local/redis/src/redis-cli -p 6381 shutdown
/usr/local/redis/src/redis-cli -p 6382 shutdown
/usr/local/redis/src/redis-cli -p 6383 shutdown
/usr/local/redis/src/redis-cli -p 6384 shutdown
/usr/local/redis/src/redis-cli -p 6385 shutdown
/usr/local/redis/src/redis-cli -p 6386 shutdown
