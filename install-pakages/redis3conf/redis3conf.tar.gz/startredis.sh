/usr/local/redis/src/redis-server /usr/local/redis/redis.conf
/usr/local/redis/src/redis-server /usr/local/redis/redis6380.conf
/usr/local/redis/src/redis-server /usr/local/redis/redis6381.conf
/usr/local/redis/src/redis-server /usr/local/redis/redis6382.conf
/usr/local/redis/src/redis-server /usr/local/redis/redis6383.conf
/usr/local/redis/src/redis-server /usr/local/redis/redis6384.conf
/usr/local/redis/src/redis-server /usr/local/redis/redis6385.conf
/usr/local/redis/src/redis-server /usr/local/redis/redis6386.conf
